const express = require("express");
const router = express.Router();
const auth = require("../controller/authcon");
const requireAuth = require("../middleware/auth");

// Auth Routes
router.post("/register", auth.registerUser);           // Register new user
router.post("/login", auth.loginUser);                 // Login & get token
router.post("/reset-request", auth.requestReset);      // Request password reset
router.post("/reset-password", auth.submitReset);      // Submit new password with code
router.get("/dashboard", requireAuth, auth.getUserDetails);  // Protected route

module.exports = router;
